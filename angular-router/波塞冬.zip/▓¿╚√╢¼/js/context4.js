/**
 * Created by Administrator on 2016/9/5.
 */
var options = angular.module('routeApp');
options.controller('context4',function(){

})