var options = angular.module('routeApp');
options.controller('context3',function(){

})